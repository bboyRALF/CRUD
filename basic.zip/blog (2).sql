-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Фев 02 2017 г., 22:17
-- Версия сервера: 10.1.10-MariaDB
-- Версия PHP: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `blog`
--

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `date` date NOT NULL,
  `photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `articles`
--

INSERT INTO `articles` (`id`, `title`, `content`, `date`, `photo`) VALUES
(23, 'Литий-ионные аккумуляторы получили встроенный огнетушитель', 'Литий-ионные аккумуляторные батареи, являющиеся “движущей силой” практически всех мобильных телефонов, планшетных компьютеров и электрических автомобилей, имеют свои слабости.', '2017-02-02', NULL),
(24, 'Разработана технология, позволяющая запасаться теплом летом и расходовать его зимой по мере необходимости', 'Стремление уйти от использования ископаемых видов топлива при отоплении жилых и производственных помещений является частью глобального плана по обеспечению более экологически чистого будущего человечества.', '2017-02-02', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `comment`
--

CREATE TABLE `comment` (
  `comment_id` int(12) NOT NULL,
  `comment_identifier_id` int(12) NOT NULL,
  `comment_identifier` text,
  `comment_identifier_hash` varchar(32) DEFAULT NULL,
  `comment_author_name` text,
  `comment_author_email` text,
  `comment_author_homepage` text,
  `comment_author_ip` varchar(20) DEFAULT NULL,
  `comment_author_host` varchar(250) DEFAULT NULL,
  `comment_author_user_agent` text,
  `comment_title` text,
  `comment_text` text,
  `comment_timestamp` int(10) NOT NULL,
  `comment_status` int(3) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf32;

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `user` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `identifier`
--

CREATE TABLE `identifier` (
  `identifier_id` int(12) NOT NULL,
  `identifier_value` text,
  `identifier_hash` varchar(32) DEFAULT NULL,
  `identifier_name` text,
  `identifier_url` text,
  `identifier_status` int(3) NOT NULL DEFAULT '0',
  `identifier_allow_comment` char(1) NOT NULL DEFAULT 'Y',
  `identifier_moderate_comment` char(1) NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=utf32;

-- --------------------------------------------------------

--
-- Структура таблицы `setting`
--

CREATE TABLE `setting` (
  `setting_name` varchar(250) NOT NULL,
  `setting_value` text
) ENGINE=MyISAM DEFAULT CHARSET=utf32;

--
-- Дамп данных таблицы `setting`
--

INSERT INTO `setting` (`setting_name`, `setting_value`) VALUES
('administration_login', 'a:3:{s:5:"login";s:5:"admin";s:5:"email";s:15:"bush88@inbox.ru";s:8:"password";s:32:"67d69efa88ed19bce8643097179df492";}'),
('script_url', '/blog2/GentleSourceComments/'),
('database_version', '1.4.1');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `comment`
--
ALTER TABLE `comment`
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `comment_identifier_id` (`comment_identifier_id`);

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `identifier`
--
ALTER TABLE `identifier`
  ADD KEY `identifier_id` (`identifier_id`),
  ADD KEY `identifier_hash` (`identifier_hash`);

--
-- Индексы таблицы `setting`
--
ALTER TABLE `setting`
  ADD KEY `setting_name` (`setting_name`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
