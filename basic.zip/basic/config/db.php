<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=blog',
    'username' => 'ralf',
    'password' => '123456',
    'charset' => 'utf8',
];
