<?= $this->render('form', [
    'model' => $model,
]) ?>