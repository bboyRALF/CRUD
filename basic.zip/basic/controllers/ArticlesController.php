<?php

namespace app\controllers;

use yii\web\Controller;
use app\models\Articles;
use Yii;
use yii\web\NotFoundHttpException;


class ArticlesController extends Controller
{

        public function actionIndex()
    {
        $articles = Articles::find()->all();

        return $this->render('index', ['model' => $articles]);
    }


    public function actionCreate()
    {
        $model = new Articles();

        // новая запись
        if($model->load(Yii::$app->request->post()) && $model->save()){
            return $this->redirect(['index']);
        }

        return $this->render('create', ['model' => $model]);
    }

    public function actionEdit($id)
    {
        $model = Articles::find()->where(['id' => $id])->one();

        // $id не найден в бд
        if($model === null)
            throw new NotFoundHttpException('Запись отсутствует.');

        // обновление записи
        if($model->load(Yii::$app->request->post()) && $model->save()){
            return $this->redirect(['index']);
        }

        return $this->render('edit', ['model' => $model]);
    }

    public function actionDelete($id)
    {
        $model = Articles::findOne($id);

        // $id не найден в бд
        if($model === null)
            throw new NotFoundHttpException('Запись отсутствует.');

        // удалить запись
        $model->delete();

        return $this->redirect(['index']);
    }
}