<?php
/**
 * Created by PhpStorm.
 * User: ALKOTRAS
 * Date: 01.02.2017
 * Time: 22:28
 */

namespace app\models;

use yii\db\ActiveRecord;
use Yii;
class Articles extends ActiveRecord
{

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'articles';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['title', 'content'], 'required'],
            [['title', 'content'], 'string'],
            [['date'],'string']

        ];
    }

}
 